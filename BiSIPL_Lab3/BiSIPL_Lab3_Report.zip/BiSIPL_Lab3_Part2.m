% BiSIPL Lab 3 - Part 2
X = load('X.dat');
fs = 256;

for i=1:3
    X(:, i) = X(:, i)-mean(X(:, i), 1);
end

plot3ch(X, fs);



[U, S, V] = svd(X);
disp(size(V))
eig = [S(1, 1), S(2, 2), S(3, 3)]';
disp(size(eig))

colors = ['b', 'g', 'r'];
hold on
for i=1:3
    plot3dv(V(:, i), S(i, i), colors(i));
end
hold off

figure;
%Y = U' * X;
disp(sumsqr(X - U*S*V'))
scatter3(U(:, 1), U(:, 2), U(:, 3), [], '.')

figure
for i=1:3
    subplot(3, 1, i)
    plot(U(:, i))
end

figure
stem(eig)

X_denoised = U(:, 2) * S(1, 1) * V(:, 2)';
figure
for i=1:3
    subplot(3, 1, i)
    plot(X_denoised(:, i))
end
figure
scatter3(X_denoised(:, 1), X_denoised(:, 2),X_denoised(:, 3))

corrcoef()
